/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package m03uf215s2_ProjecteI;

import java.util.Scanner;

/**
 *
 * @author Alicia
 */
public class ProjecteI_Tasca1 {

  private String entrarText(String missatgeExplicatiu){
        Scanner scanner = new Scanner(System.in);
        String ret;
        do{
            System.out.print(missatgeExplicatiu);        
            ret = scanner.nextLine();
            if(ret.length()==0){
                System.out.println("Una cadena buida no Ã©s un entrada vÃ lida. Escriviu un text, si us plau.");
            }
        }while(ret.length()==0);
        return ret;
    }

    
    /*******************************************************/
    /*                    ProjecteI_Tasca 1                */
    /*******************************************************/
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ProjecteI_Tasca1 prg = new ProjecteI_Tasca1();
        prg.prova();
    }
    
    public void prova() {
        //Prova la funciÃ³ entrarText
        String valor = entrarText("Entra un text qualsevol:\n");
        System.out.print("El texte entrat per teclat Ã©s:" );
        System.out.println(valor);
    }
    
}
