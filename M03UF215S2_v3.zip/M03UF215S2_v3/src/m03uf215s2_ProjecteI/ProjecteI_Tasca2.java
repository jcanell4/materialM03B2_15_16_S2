/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package m03uf215s2_ProjecteI;

/**
 *
 * @author Alicia
 */
public class ProjecteI_Tasca2 {

    /**
     * @param args the command line arguments
     */
     private String obteDorsalCiclista(String nomCiclista,  int ordreInscripcio, String codiEquip) {
        String ret, nomC;
        nomC=nomCiclista.substring(0, 3);
        ret=nomC+""+ordreInscripcio+""+codiEquip;
        return ret;
    }
    
    /*******************************************************/
    /*                   ProjecteI_Tasca 2          */
    /*******************************************************/
    public static void main(String[] args) {
        // TODO code application logic here
        ProjecteI_Tasca2 prg = new ProjecteI_Tasca2();
        prg.prova();
    }
    private void prova() {
        String nomCiclista = "Perico Indurain";
        String codiEquip="ONZ";
        int ordreIns=4;  
        System.out.println("El dorsal del ciclista "+nomCiclista+" es "+obteDorsalCiclista(nomCiclista, ordreIns,codiEquip)); 
    }
}
