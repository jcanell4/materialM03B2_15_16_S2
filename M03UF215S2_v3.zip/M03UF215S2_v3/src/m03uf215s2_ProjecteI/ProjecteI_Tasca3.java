/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package m03uf215s2_ProjecteI;

/**
 *
 * @author Alicia
 */
public class ProjecteI_Tasca3 {
    
public static final int NOM_ETAPA=0;
public static final int ORIGEN_ETAPA=1;
public static final int DESTI_ETAPA=2;
public static final int TIPUS_ETAPA=3;

 int posEtapaMesLlarga (double[] kmEtapa){
    int posMaxEtapa=0;
    for(int i=1;i<kmEtapa.length;i++){
             if(kmEtapa[i]>kmEtapa[posMaxEtapa]){
                posMaxEtapa= i;
            }
 }
    return posMaxEtapa;
}
void mostrarEtapaMesLlarga(String nomEtapaMesLlarga,double distanciaEtapaMesLlarga,String tipusEtapaMesLlarga){
    System.out.print("L'etapa més llarga és l'" + nomEtapaMesLlarga + " amb " +distanciaEtapaMesLlarga + " i es de tipus " + tipusEtapaMesLlarga);
    System.out.println();
}

public static void main(String[] args) {
    //adapteu la instanciació del programa d'acord amb el nom del fitxer (i nom de la classe) on treballeu.
    ProjecteI_Tasca3 prg = new ProjecteI_Tasca3();  //canvieu FuncionsIArrays pel nom del vostre fitxer.
    prg.prova();
}    

private void prova(){
String[][] etapes = {
        {"Etapa 1","Barcelona", "Girona","Plana"}
       ,{"Etapa 2","Girona", "Berga", "Muntanya"}
       ,{"Etapa 3","Berga", "Sort", "Alta muntanya"}
       ,{"Etapa 4","Sort", "Balaguer", "Alta muntanya"}
       ,{"Etapa 5","Balaguer", "Amposta", "Plana"}
       ,{"Etapa 6","Amposta", "Manresa", "Plana"}
       ,{"Etapa 7","Manresa", "Mataró", "Muntanya"}
    };
    double[] distanciaEtapa ={185.2, 191.8, 156.6, 188.4, 195.4, 194.1, 126.6};
    //cerquem la posició on es troba l'etapa més llarga
    int posMaxEtapa=posEtapaMesLlarga(distanciaEtapa);
    //mostrem les dades de l'etapa més llarga
    mostrarEtapaMesLlarga(etapes[posMaxEtapa][NOM_ETAPA],distanciaEtapa[posMaxEtapa],etapes[posMaxEtapa][TIPUS_ETAPA]);
}
}