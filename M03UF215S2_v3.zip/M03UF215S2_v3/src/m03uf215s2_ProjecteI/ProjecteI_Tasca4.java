/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package m03uf215s2_ProjecteI;

/**
 *
 * @author Alicia
 */
public class ProjecteI_Tasca4 {

    /**
     * @param args the command line arguments
     */
    public static final int CODI_EQUIP=0;
    public static final int NOM_EQUIP=1;
    void mostrarLlistaEquips(String[][] equips,int [] comptadorCiclEquip) {
        String formatCapcalera = " %3s %-20s %1s";
        String formatLinia = " %3s  %-30s %1d";
        int max = equips.length;
        System.out.println();
        System.out.println("Equips participants:  " + max);
        System.out.println();
        System.out.println(" Dades d'equips  ");
        System.out.println("--------------------------------------------------");
        System.out.printf(formatCapcalera, "CODI", "EQUIP","CICLISTES INSCRITS");
        System.out.println();
        System.out.println("--------------------------------------------------");
        for(int i=0; i<equips.length; i++){
          String resultat= String.format(formatLinia, equips[i][CODI_EQUIP], equips[i][NOM_EQUIP],comptadorCiclEquip[i]);   
           System.out.println(resultat);
        }
        System.out.println();
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        ProjecteI_Tasca4 prg = new ProjecteI_Tasca4();  //canvieu FuncionsIArrays pel nom del vostre fitxer.
        prg.prova();
    }
    private void prova(){
        String[][] equips = {
         {"ONZ", "ONZE"}
        ,{"TNK", "Tinkof"}
        ,{"BCH", "Biancho"}
        ,{"BRW", "Bartoloworld"}
        ,{"MVX", "Movixtar"}
        ,{"BIC", "Bich"}
        ,{"CFD", "Cofidos"}
        ,{"FON", "Fono"}
        ,{"MTX", "Matrix"}
    };
        int[] comptadorCiclEquip={2,3,1,5,4,4,5,1,3};    
        mostrarLlistaEquips(equips,comptadorCiclEquip);
}
}
