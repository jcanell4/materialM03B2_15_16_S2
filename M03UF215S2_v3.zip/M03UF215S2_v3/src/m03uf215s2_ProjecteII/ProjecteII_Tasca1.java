/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package m03uf215s2_ProjecteII;
/**
 *
 * @author Alicia
 */
public class ProjecteII_Tasca1 {

    /**
     * @param args the command line arguments
     */
     public boolean verificarData(String valor){
        boolean ok= valor.length()==10;
        for(int i =0; ok && i<2; i++){
            ok = valor.charAt(i)>='0'
                        && valor.charAt(i)<='9';
        }
        
        ok = ok && valor.charAt(2)=='/';
        
        for(int i =3; ok && i<5; i++){
            ok = valor.charAt(i)>='0'
                        && valor.charAt(i)<='9';
        }

        ok = ok && valor.charAt(5)=='/';
        
        for(int i =6; ok && i<10; i++){
            ok = valor.charAt(i)>='0'
                        && valor.charAt(i)<='9';
        }

        return ok;
    }
    public static void main(String[] args) {
        // TODO code application logic here
        ProjecteII_Tasca1 prg = new ProjecteII_Tasca1();  
        prg.prova();
    }
    private void prova(){
        
       String[] dataNaixement = {"12/10/1996","1111/10/19"};
        boolean valida=false;
        for (int i=0;i<dataNaixement.length;i++){
            valida=verificarData(dataNaixement[i]);
            System.out.println("La data "+dataNaixement[i]+" es "+valida);
            }   
    }
    
}
