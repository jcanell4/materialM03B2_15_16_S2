/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package m03uf215s2_ProjecteII;

/**
 *
 * @author Alicia
 */
public class ProjecteII_Tasca3 {

    /**
     * @param args the command line arguments
     */
    static final int CODIEQUIP=0;
    static final int NOMEQUIP=1;
    static final int CICLISTESXEQUIP=5;
    
    public int validaCodiEquip(String[][] equips, String codiEquip){
        int posCodiEquip=-1;
        //comparar el codi de l'equip amb tots els codis d'equips existents, si existeix retorna la posició en la que es troba
        for(int i=0;i<equips.length;i++){
            if(equips[i][CODIEQUIP].equalsIgnoreCase(codiEquip))
                posCodiEquip=i;
        }
        return posCodiEquip;
    }
    public boolean validaComptadorCiclistesEquip(int comptadorCiclista){
        boolean valida=false;
        //es comprova que l'equip no té més de 5 ciclistes inscrits
        if (comptadorCiclista<CICLISTESXEQUIP)
            valida=true;
        return valida;
    }
    public boolean validarEquipCiclista( String[][] equips, String codiEquip,int[] comptadorCiclista){
        boolean validaEquipCiclista=false;
        int posCiclistaEquip;
        
        //comprovar si el codi d'equip existeix. Si és el cas, retorna la posició on s'ha trobat, sinó retorna -1
        posCiclistaEquip=validaCodiEquip(equips,codiEquip);
        
        //si s'ha trobat l'equip, la posició serà major o igual que 0
        if(posCiclistaEquip>=0){
            //comprovar el nombre de ciclistes inscrits en aquell equip
            if(validaComptadorCiclistesEquip(comptadorCiclista[posCiclistaEquip]))
                validaEquipCiclista=true;
        }  
        return validaEquipCiclista;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        ProjecteII_Tasca3 prg = new ProjecteII_Tasca3();  
        prg.prova();
    }
    private void prova(){
        String[][] equips = {
         {"ONZ", "ONZE"}
        ,{"TNK", "Tinkof"}
        ,{"BCH", "Biancho"}
        ,{"BRW", "Bartoloworld"}
        ,{"MVX", "Movixtar"}
        ,{"BIC", "Bich"}
        ,{"CFD", "Cofidos"}
        ,{"FON", "Fono"}
        ,{"MTX", "Matrix"}
         };
        int[] comptadorCiclEquip={2,3,1,5,4,4,5,1,3};    
        boolean valida;
        //suposem dos exemples de codis d'equip per fer la prova de la funció  validarEquipCiclista
        String[] codiEquip={"ONZ","ABC"};
        
        for (int i=0;i<codiEquip.length;i++){
            valida=validarEquipCiclista(equips,codiEquip[i],comptadorCiclEquip);
           System.out.println("L'equip "+codiEquip[i]+" "+valida);
            }
        
    }
}
