/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package m03uf215s2_ProjecteII;
/**
 *
 * @author Alicia
 */
public class ProjecteII_Tasca5 {
    /**
     * @param args the command line arguments
     */
 
   
   int posicioCiclistaTempsMinimCompeticio(int[] totalSegonsCiclista,int numCiclistes){
       int minTemps;
       int posTempsMinimCompeticio=0;
       minTemps=totalSegonsCiclista[0];
       for(int i=1;i<numCiclistes;i++){
           if(totalSegonsCiclista[i]<=minTemps){
               minTemps=totalSegonsCiclista[i];
               posTempsMinimCompeticio=i;
           }
      }
       return posTempsMinimCompeticio;
   }
    
   void mostrarTotalSegonsCiclistaCompeticio(int numCiclistes,int[] totalTempsCiclistaCompeticio){
       System.out.println("---Temps, en segons, realitzat per cada ciclista en totes les etapes realitzades---");
        for (int i=0;i<numCiclistes;i++)
             System.out.println("El ciclista "+i+ " ha realitzat la competició en un total de " + totalTempsCiclistaCompeticio[i]+ " segons");
   }
   void mostrarCiclistaGuanyador(int posCiclistaGuanyador){
       System.out.println("GUANYADOR COMPETICIÓ:");
       System.out.println("El ciclista guanyador es el " + posCiclistaGuanyador);
   }
   int[] totalTempsEnSegonsCiclistaTotesEtapes(int[][] tempsEnSegonsCiclistesXEtapes,int numEtapes, int numCiclistes){
        int[] totalTempsCiclistesCompeticio = new int[numCiclistes] ; //array que emm temps total de cada ciclista en totes les etapes
        //recorrem array de temps per acumular el temps realitzat per cada ciclista en totes les etapes
        for (int j=0;j<numCiclistes;j++){ 
            totalTempsCiclistesCompeticio[j]=0;
            for (int i=0;i<numEtapes;i++){
                //acumulem el total de temps de cada ciclista per totes les etapes
                totalTempsCiclistesCompeticio[j]+= tempsEnSegonsCiclistesXEtapes[i][j];
                }
            }
         return  totalTempsCiclistesCompeticio;
   }
    int ciclistaGuanyadorCompeticio(int[][]tempsEnSegonsCiclistesXEtapes,int numEtapes,int numCiclistes){
        int[] totalSegonsCiclista; //definim un array per emmagatzemar el temps total en segons de cada ciclista en totes les etapes
        
        //definirem un mètode per calcular els segons totals de cada ciclista a totes les etapes
        totalSegonsCiclista=totalTempsEnSegonsCiclistaTotesEtapes(tempsEnSegonsCiclistesXEtapes,numEtapes,numCiclistes);
      
        //mostrarTotalSegonsCiclistaCompeticio(numCiclistes, totalSegonsCiclista);
        //calcularem el mínim de l'array anterior i obtindrem el valor de la posició que ocupa el ciclista amb mínim temps
        int posCiclistaGuanyador=posicioCiclistaTempsMinimCompeticio(totalSegonsCiclista,numCiclistes);
    
        return posCiclistaGuanyador; 
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        ProjecteII_Tasca5 prg = new ProjecteII_Tasca5();  
        prg.prova();
    }
    
    private void prova(){
        //suposarem 2 etapes, 4 ciclistes
        int numEtapes=2;
        int numCiclistes=4;
        //array que representa el temps, en segons, que ha invertit cada ciclista en cadascuna de les etapes
        int[][] tempsEnSegonsCiclistesXEtapes={{3422,4502,4382,4022},
                                               {3023,3323,2723,2663}};
        
      
        //Ciclista guanyador de la competició, esbrinem la posició del ciclista guanyador
        int posCiclistaGuanyador=ciclistaGuanyadorCompeticio(tempsEnSegonsCiclistesXEtapes,numEtapes,numCiclistes);
        //mostrarem la informació del ciclista guanyador
        mostrarCiclistaGuanyador(posCiclistaGuanyador);
    }
}
